import asyncio
import threading
import random
from pystyle import Colors, Box, Write, Center, Colorate, Anime
import time
import requests
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import whois
import os
import string
from faker import Faker
import socket
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
a=input(Colorate.Horizontal(Colors.blue_to_white, ("Введите ключ:")))
if a!="imbakey1488":
	print(Colorate.Horizontal(Colors.blue_to_white, (f"Неверный ключ!")))
	exit()
else:
	print(Colorate.Horizontal(Colors.blue_to_white, (f"Ключ верен!")))
def clear_console():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
print(Colorate.Horizontal(Colors.blue_to_white, ("MEFIK | TELEGRAM - @TaymDLC")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┏━━━━━━━━━━━━━━━━━━━━━━━┓")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 1 - Поиск по номеру   ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 2 - Поиск по телеге   ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 3 - Поиск по вк       ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 4 - Поиск по ОК       ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 5 - Снос всего        ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 6 - Отправить ядерку  ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 7 - Чашка пельменей   ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 8 - Мамин супчик      ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 9 - Разморозить курицу┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 10 - Насрать в лоток  ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 11 - Почистить лоток  ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 12 - Отрубить свет в д┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃оме                    ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 13 - Позвать кота к се┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃бе                     ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 14 - Сват по бобофону ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 15 - Сват от лица хомя┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ка                     ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 16 - Получить +888    ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 17 - Смыть унитаз     ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 18 - Сват от имени уни┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃таза                   ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 19 - Сват от имени ко ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃та                     ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 20 - Тест на ваш IQ   ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 21 - О софте          ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┃ 22 - Новости          ┃")))
print(Colorate.Horizontal(Colors.blue_to_white, ("┗━━━━━━━━━━━━━━━━━━━━━━━┛")))
b = 1
x = 0
g = 0
x = int(input())
if x == 1:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите номер:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Одну секунду...")))
	time.sleep(4)
	print(Colorate.Horizontal(Colors.blue_to_white, ("Скопировано!")))
	while b == 1:
		g = input()
if x == 2:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите юзернейм:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Скопировано!")))
	while b == 1:
		g = input()
if x == 3:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите ID:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Скопировано!")))
	while b == 1:
		g = input()
if x == 4:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите ссылку на страницу:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Скопировано!")))
	while b == 1:
		g = input()
if x == 5:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите юзернейм:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Снесено!")))
	while b == 1:
		g = input()
if x == 6:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Куда отправить ядерку:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Ядерка отправлена!")))
	while b == 1:
		g = input()
if x == 7:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите количество пельменей в чашке:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Проверь стол!")))
	while b == 1:
		g = input()
if x == 8:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Куда заспавнить супчик?")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Проверь стол!")))
	while b == 1:
		g = input()
if x == 9:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Ну а вот это ты давай сам")))
	while b == 1:
		g = input()
if x == 10:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Насрано!")))
	while b == 1:
		g = input()
if x == 11:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Убрано!")))
	while b == 1:
		g = input()
if x == 12:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Цыпадум придёт!")))
	while b == 1:
		g = input()
if x == 13:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Пушистик уже идёт!")))
	while b == 1:
		g = input()
if x == 14:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Спецназ едет к тебе! бобофон не спас")))
	while b == 1:
		g = input()
if x == 15:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите юзер:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Спецназ уже у него дома! А ты незамечен!")))
	while b == 1:
		g = input()
if x == 16:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Покупай рофл софт Easy +888 у @Wooder_zone!")))
	while b == 1:
		g = input()
if x == 17:
	print(Colorate.Horizontal(Colors.blue_to_white, ("Унитаз не смыт! Всё доели палитры!")))
	while b == 1:
		g = input()
if x == 18:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите юзер:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Спецназ уже у него дома! А ты незамечен!")))
	while b == 1:
		g = input()
if x == 19:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Введите юзер:")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Спецназ уже у него дома! А ты незамечен!")))
	while b == 1:
		g = input()
if x == 20:
	c = input(Colorate.Horizontal(Colors.blue_to_white, ("Сколько вам лет?")))
	print(Colorate.Horizontal(Colors.blue_to_white, ("Ваш IQ гениален ведь вы скачали лучший софт!")))
	while b == 1:
		g = input()
if x == 21:
	print(Colorate.Horizontal(Colors.blue_to_white, ("О софте: Создатель - @Wooder_zone Кидали идеи: Сглыпа и Дед")))
	while b == 1:
		g = input()
if x == 22:
        print(Colorate.Horizontal(Colors.blue_to_white, ("Ваша версия: 1.5")))
        print(Colorate.Horizontal(Colors.blue_to_white, ("Что нового?")))
        print(Colorate.Horizontal(Colors.blue_to_white, ("Добавлен новый пункт в меню: Новости")))
        print(Colorate.Horizontal(Colors.blue_to_white, ("Небольшой фикс функций")))
        time.sleep(6)
        print(Colorate.Horizontal(Colors.blue_to_white, ("пасхалко!")))